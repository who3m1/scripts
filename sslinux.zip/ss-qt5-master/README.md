# ss-qt5
shadowsocks-qt5 在ubuntu18.04的deb包

#### 在ubuntu上安装shadowsocks-qt5所需要的依赖包
#### sudo dpkg -i *.deb 然后sudo apt-get install -f修复依赖
